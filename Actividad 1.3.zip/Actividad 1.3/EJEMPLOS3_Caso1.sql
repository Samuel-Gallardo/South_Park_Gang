SELECT
    to_char(c.numrun, '99g999g999')
    || '-'
    || c.dvrun AS "RUN CLIENTE",
    initcap(c.pnombre
            || ' '
            || c.snombre
            || ' '
            || c.appaterno
            || ' '
            || c.apmaterno) AS "NOMBRE CLIENTE",
    p.nombre_prof_ofic "PROFESION / OFICIO",
    to_char(c.fecha_nacimiento, 'dd')
    || ' de '
    || to_char(c.fecha_nacimiento, 'Month')"DIA DE CUMPLEA�OS"
FROM
    cliente            c
    INNER JOIN profesion_oficio   p ON p.cod_prof_ofic = c.cod_prof_ofic
WHERE
    EXTRACT(MONTH FROM c.fecha_nacimiento) = EXTRACT(MONTH FROM sysdate) + 1
ORDER BY
    4,
    c.appaterno;