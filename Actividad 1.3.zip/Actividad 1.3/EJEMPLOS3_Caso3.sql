SELECT
    to_char(cc.fecha_otorga_cred, 'MM/YYYY') AS "MES TRANSACCI�N",
    cr.nombre_credito AS "TIPO DE CR�DITO",
    to_char(SUM(cc.monto_credito), 'fml999g999g999') AS "MONTO TOTAL DEL CR�DITO",
    to_char(SUM(
        CASE
            WHEN cc.monto_credito BETWEEN 100000 AND 1000000 THEN
                cc.monto_credito * 0.01
            WHEN cc.monto_credito BETWEEN 1000001 AND 2000000 THEN
                cc.monto_credito * 0.02
            WHEN cc.monto_credito BETWEEN 2000001 AND 4000000 THEN
                cc.monto_credito * 0.03
            WHEN cc.monto_credito BETWEEN 4000001 AND 6000000 THEN
                cc.monto_credito * 0.04
            WHEN cc.monto_credito > 6000000                 THEN
                cc.monto_credito * 0.07
            ELSE
                0
        END
    ), 'fml999g999g999') AS "MONTO TOTAL APORTE SBIF"
FROM
    credito_cliente   cc
    INNER JOIN credito           cr ON cr.cod_credito = cc.cod_credito
WHERE
    EXTRACT(YEAR FROM cc.fecha_otorga_cred) = EXTRACT(YEAR FROM sysdate) - 1
GROUP BY
    to_char(cc.fecha_otorga_cred, 'MM/YYYY'),
    cr.nombre_credito
ORDER BY
    "MES TRANSACCI�N" ASC,
    "TIPO DE CR�DITO" ASC;