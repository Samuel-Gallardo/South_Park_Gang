SELECT
    EXTRACT(YEAR FROM sysdate) "A�O TRIBUTARIO",
    to_char(numrun, '99g999g999')
    || '-'
    || dvrun "RUN CLIENTE",
    initcap(pnombre
            || ' '
            || substr(snombre, 1, 1)
            || nvl2(snombre, '. ', '')
            || appaterno
            || ' '
            || apmaterno)"NOMBRE CLIENTE",
    COUNT(monto_total_ahorrado)"TOTAL PROD. INV AFECTOS IMPTO",
    to_char(monto_total_ahorrado, 'fml99g999g999')"MONTO TOTAL AHORRADO"
FROM
    cliente       c
    INNER JOIN producto_inversion_cliente   p ON c.nro_cliente = p.nro_cliente
WHERE p.monto_total_ahorrado>0
GROUP BY
    numrun,
    dvrun,
    pnombre,
    snombre,
    appaterno,
    apmaterno,
    monto_total_ahorrado
ORDER BY
    appaterno ASC