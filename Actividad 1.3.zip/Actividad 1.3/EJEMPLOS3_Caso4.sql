SELECT
    to_char(numrun, '99g999g999')
    || '-'
    || dvrun "RUN CLIENTE",
    initcap(pnombre
            || ' '
            || snombre
            || ' '
            || appaterno
            || ' '
            || apmaterno)"NOMBRE CLIENTE",
    to_char(ma.monto_total_ahorrado, 'fml999g999g999')"MONTO TOTAL AHORRADO",
    CASE
        WHEN ma.monto_total_ahorrado BETWEEN 100000 AND 1000000 THEN
            'BRONCE'
        WHEN ma.monto_total_ahorrado BETWEEN 1000001 AND 4000000 THEN
            'PLATA'
        WHEN ma.monto_total_ahorrado BETWEEN 4000001 AND 8000000 THEN
            'SILVER'
        WHEN ma.monto_total_ahorrado BETWEEN 8000001 AND 15000000 THEN
            'GOLD'
        WHEN ma.monto_total_ahorrado > 15000000 THEN
            'PLATINUM'
        ELSE
        ' '
    END "CATEGORIA CLIENTE"
FROM
    cliente
    INNER JOIN producto_inversion_cliente ma ON ma.nro_cliente = cliente.nro_cliente
WHERE ma.monto_total_ahorrado>=100000
ORDER BY cliente.appaterno, ma.monto_total_ahorrado DESC