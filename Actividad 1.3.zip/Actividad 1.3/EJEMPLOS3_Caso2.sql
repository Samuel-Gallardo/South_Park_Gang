SELECT
    to_char(c.numrun, '99g999g999')
    || '-'
    || upper(c.dvrun) AS run,
    initcap(c.pnombre
            || ' '
            || c.snombre
            || ' '
            || c.appaterno
            || ' '
            || c.apmaterno) AS "NOMBRE CLIENTE",
    to_char(SUM(cc.monto_credito), 'fml999g999g999') AS "MONTO SOLICITADO CREDITOS",
    to_char(round(SUM(cc.monto_credito * 0.012)), 'fml999g999g999') AS "TOTAL PESOS TODOSUMA"
FROM
    cliente           c
    JOIN credito_cliente   cc ON c.nro_cliente = cc.nro_cliente
WHERE
    EXTRACT(YEAR FROM cc.fecha_otorga_cred) = EXTRACT(YEAR FROM sysdate) - 1
GROUP BY
    c.numrun,
    c.dvrun,
    c.pnombre,
    c.snombre,
    c.appaterno,
    c.apmaterno
ORDER BY
    round(SUM(cc.monto_credito * 0.012)),
    c.appaterno;