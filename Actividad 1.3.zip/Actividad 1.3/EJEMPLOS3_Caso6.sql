
--informe 1
SELECT
     TO_CHAR(c.numrun,'99G999G999')||'-'||REPLACE(c.dvrun,'k','K') AS "RUN CLIENTE",
     INITCAP(c.pnombre||' '||c.snombre||' '||c.appaterno||' '||c.apmaterno) AS "NOMBRE CLIENTE",
     COUNT(cc.monto_solicitado) AS "TOTAL CREDITOS SOLICITADOS",
     TO_CHAR(SUM(cc.monto_solicitado),'fml99g999g999') AS "MONTO TOTAL CREDITOS"
 FROM
     cliente c
 INNER JOIN credito_cliente cc ON c.nro_cliente = cc.nro_cliente
 GROUP BY c.numrun,c.dvrun,c.pnombre,c.snombre,c.appaterno,c.apmaterno
 ORDER BY c.appaterno ASC;

-- informe 2 
SELECT
    TO_CHAR(numrun,'99G999G999')||'-'||UPPER(dvrun) AS "RUN CLIENTE",
    INITCAP(pnombre||' '||snombre||' '||appaterno||' '||apmaterno) AS "NOMBRE CLIENTE",
    CASE 
        WHEN MIN(m.cod_tipo_mov) LIKE 1 THEN
            to_char(m.monto_movimiento,'fml99g999g999')
        WHEN MIN(m.cod_tipo_mov) LIKE 2 THEN
            'No realiz�'
    END AS BONO,
    CASE 
        WHEN MIN(m.cod_tipo_mov) LIKE 2 THEN
            to_char(m.monto_movimiento,'fml99g999g999')
        WHEN MIN(m.cod_tipo_mov) LIKE 1 THEN
            'No realiz�'
    END AS RESCATES
FROM
    cliente c
INNER JOIN movimiento m ON c.nro_cliente = m.nro_cliente
WHERE EXTRACT (YEAR FROM m.fecha_movimiento) LIKE 2025
GROUP BY numrun,dvrun,pnombre,snombre,appaterno,apmaterno,m.monto_movimiento
ORDER BY appaterno


