SELECT
    to_char(numrun_emp, '99g999g999')
    || '-'
    || dvrun_emp "RUN EMPLEADO",
    initcap(pnombre_emp||' '||snombre_emp||' '||appaterno_emp||' '||apmaterno_emp) "NOMBRE COMPLETO EMPLEADO",
    TO_CHAR(sueldo_base,'fml999g999g999') "SUELDO BASE",
    '%'||to_char(trunc(sueldo_base/100000)) "PORCENTAJE MOVILIZACION",
     to_char(((trunc(sueldo_base/100000)) * sueldo_base)*0.01,'fml999g999g999') "VALOR MOVILIZACION"
FROM
    empleado
order by 4 desc;