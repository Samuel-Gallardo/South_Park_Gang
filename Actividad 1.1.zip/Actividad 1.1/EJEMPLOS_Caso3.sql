SELECT
    to_char(numrun_emp, '99g999g999')
    || '-'
    || dvrun_emp "RUN EMPLEADO",
    initcap(pnombre_emp
            || ' '
            || snombre_emp
            || ' '
            || appaterno_emp
            || ' '
            || apmaterno_emp) "NOMBRE COMPLETO EMPLEADO",
    to_char(sueldo_base, 'fml999g999g999') "SUELDO BASE",
    fecha_nac "FECHA NACIMIENTO",
    substr(pnombre_emp, 1, 3)
    || length(pnombre_emp)
    || '*'
    || substr(sueldo_base, - 1)
    || dvrun_emp
    || (EXTRACT(YEAR FROM sysdate) - EXTRACT(YEAR FROM fecha_contrato)) "NOMBRE USUARIO",
    substr(numrun_emp,3,1)||EXTRACT(YEAR FROM fecha_contrato)+2||substr(sueldo_base,-3)-1||substr(appaterno_emp,-2)||extract(month from sysdate) clave
FROM
    empleado
order by appaterno_emp