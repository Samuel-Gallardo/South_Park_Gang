SELECT
    to_char(numrun_cli, '99g999g999')
    || '-'
    || dvrun_cli "RUN CLIENTE",
    lower(pnombre_cli)
    || ' '
    || initcap(snombre_cli)
    || ' '
    || upper(appaterno_cli
             || ' '
             || apmaterno_cli)"NOMBRE COMPLETO CLIENTE",
    fecha_nac_cli "FECHA NACIMIENTO"
FROM
    cliente
WHERE to_char(fecha_nac_cli,'DD/MM')= '21/08'

ORDER BY appaterno_cli