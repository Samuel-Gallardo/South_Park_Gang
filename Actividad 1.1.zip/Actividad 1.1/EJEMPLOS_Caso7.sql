SELECT
    to_char(numrun_emp, '99g999g999')
    || '-'
    || dvrun_emp AS "RUN EMPLEADO",
    initcap(pnombre_emp
            || ' '
            || snombre_emp
            || ' '
            || appaterno_emp
            || ' '
            || apmaterno_emp) AS "NOMBRE EMPLEADO",
    ( EXTRACT(YEAR FROM sysdate) - EXTRACT(YEAR FROM fecha_contrato) ) AS "A�OS CONTRATADO",
    to_char(sueldo_base, 'fml99g999g999') AS "SUELDO BASE",
    to_char(((EXTRACT(YEAR FROM sysdate) - EXTRACT(YEAR FROM fecha_contrato)) * 0.01) * sueldo_base, 'fml999g999g999') AS "VALOR MOVILIZACION"
    ,
    CASE
        WHEN sueldo_base >= 450000 THEN
            to_char((to_number(substr(to_char(sueldo_base), 1, 1)) * 0.01) * sueldo_base, 'fml999g999g999')
        WHEN sueldo_base < 450000  THEN
            to_char((to_number(substr(to_char(sueldo_base), 1, 2)) * 0.01) * sueldo_base, 'fml999g999g999')
    END AS "BONO EXTRA MOVILIZACION",
    to_char(((EXTRACT(YEAR FROM sysdate) - EXTRACT(YEAR FROM fecha_contrato)) * 0.01) * sueldo_base +
        CASE
            WHEN sueldo_base >= 450000 THEN
                (to_number(substr(to_char(sueldo_base), 1, 1)) * 0.01) * sueldo_base
            WHEN sueldo_base < 450000  THEN
                (to_number(substr(to_char(sueldo_base), 1, 2)) * 0.01) * sueldo_base
        END, 'fml999g999g999') AS "VALOR TOTAL MOVILIZACION"
FROM
    empleado;