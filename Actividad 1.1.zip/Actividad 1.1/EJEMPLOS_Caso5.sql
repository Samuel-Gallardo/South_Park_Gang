SELECT
    '0'
    || to_char(EXTRACT(MONTH FROM sysdate)
               || '/'
               || EXTRACT(YEAR FROM sysdate)) AS mes_anno_proceso,
    id_arriendo,
    nro_patente,
    numrun_cli,
    fecha_ini_arriendo,
    dias_solicitados,
    fecha_devolucion,
    greatest(fecha_devolucion -(fecha_ini_arriendo + dias_solicitados), 0) AS dias_atraso,
    greatest(fecha_devolucion -(fecha_ini_arriendo + dias_solicitados), 0) * 25500 AS monto_multa
FROM
    arriendo_camion
ORDER BY
    fecha_ini_arriendo,
    nro_patente;