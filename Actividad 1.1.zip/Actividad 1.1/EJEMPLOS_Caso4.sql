CREATE TABLE HIST_REBAJA_ARRIENDO (
    ANNO_PROCESO NUMBER(4),               
    nro_patente VARCHAR2(20),             
    valor_arriendo_dia_SR NUMBER(10,2),   
    valor_garantia_dia_SR NUMBER(10,2),   
    annos_antiguedad NUMBER(3),           
    valor_arriendo_dia_CR NUMBER(10,2),   
    valor_garantia_dia_CR NUMBER(10,2)   
);

/*INSERT INTO HIST_REBAJA_ARRIENDO (
    ANNO_PROCESO, nro_patente, valor_arriendo_dia_SR, valor_garantia_dia_SR, 
    annos_antiguedad, valor_arriendo_dia_CR, valor_garantia_dia_CR
)*/
SELECT
    EXTRACT(YEAR FROM sysdate) "ANNIO_PROCESO",
    nro_patente,
    valor_arriendo_dia,
    valor_garantia_dia,
    EXTRACT(YEAR FROM sysdate) - anio antiguedad,
    CASE
        WHEN ( EXTRACT(YEAR FROM sysdate) - anio ) > 5 THEN
            valor_arriendo_dia - valor_arriendo_dia * ( ( EXTRACT(YEAR FROM sysdate) - anio ) * 0.01 )
        ELSE
            valor_arriendo_dia
    END "VALOR_ARRIENDO_DIA_CR",
    CASE
        WHEN ( EXTRACT(YEAR FROM sysdate) - anio ) > 5 THEN
            valor_garantia_dia - valor_arriendo_dia * ( ( EXTRACT(YEAR FROM sysdate) - anio ) * 0.01 )
        ELSE
            valor_garantia_dia
    END "VALOR_GARANTIA_DIA_CR"
FROM
    camion
ORDER BY 5 DESC,nro_patente;