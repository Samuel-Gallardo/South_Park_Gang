SELECT
    '0'
    || to_char(EXTRACT(MONTH FROM sysdate)
               || '/'
               || EXTRACT(YEAR FROM sysdate)) AS mes_anno_proceso,
    to_char(numrun_emp, '99g999g999')
    || '-'
    || dvrun_emp "RUN EMPLEADO",
    initcap(pnombre_emp
            || ' '
            || snombre_emp
            || ' '
            || appaterno_emp
            || ' '
            || apmaterno_emp) "NOMBRE COMPLETO EMPLEADO",
    to_char(sueldo_base, 'fml999g999g999') "SUELDO BASE",
    CASE
        WHEN sueldo_base BETWEEN 320000 AND 450000 THEN
            to_char(2000000 * 0.5, 'fml999g999g999')
        WHEN sueldo_base BETWEEN 450001 AND 600000 THEN
            to_char(2000000 * 0.35, 'fml999g999g999')
        WHEN sueldo_base BETWEEN 600001 AND 900000 THEN
            to_char(2000000 * 0.25, 'fml999g999g999')
        WHEN sueldo_base BETWEEN 900001 AND 1800000 THEN
            to_char(2000000 * 0.15, 'fml999g999g999')
        WHEN sueldo_base > 1800000                THEN
            to_char(2000000 * 0.1, 'fml999g999g999')
    END "BONIFICACION POR UTILIDADES"
FROM
    empleado
ORDER BY
    appaterno_emp