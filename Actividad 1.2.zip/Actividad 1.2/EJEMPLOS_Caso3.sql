SELECT 
    to_char(run_jefe,'99g999g999') AS "RUN JEFE SIN DV",
    COUNT(*) AS "TOTAL EMPLEADOS A CARGO",
    to_char(MAX(salario),'fml9g999g999') "SALARIO M�XIMO",
    COUNT(*) * 10 || '%' || ' del Salario Maximo' AS "PORCENTAJE DE BONIFICACION",
    to_char((COUNT(*) * 10) / 100.0 * MAX(salario),'fml999g999')  AS "BONO"
FROM empleado
WHERE run_jefe IS NOT NULL
GROUP BY run_jefe
ORDER BY COUNT(*) ASC;