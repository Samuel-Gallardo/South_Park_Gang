SELECT
    tituloid AS "CODIGO DEL LIBRO",
    COUNT(tituloid) AS "TOTAL DE VECES SOLICITADO",
    CASE
        WHEN COUNT(tituloid) = 1 THEN
            'No se requiere comprar nuevos ejemplares'
        WHEN COUNT(tituloid) BETWEEN 2 AND 3 THEN
            'Se requiere comprar 1 nuevo ejemplar'
        WHEN COUNT(tituloid) BETWEEN 4 AND 5 THEN
            'Se requiere comprar 2 nuevos ejemplares'
        WHEN COUNT(tituloid) > 5 THEN
            'Se requiere comprar 4 nuevos ejemplares'
    END AS "SUGERENCIA",
    fecha_ini_prestamo
FROM
    prestamo
GROUP BY
    tituloid, fecha_ini_prestamo
having extract(year from fecha_ini_prestamo) = extract(year from sysdate)- 1
ORDER BY
    2 DESC;
