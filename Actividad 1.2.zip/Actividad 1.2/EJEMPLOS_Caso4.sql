SELECT
    id_escolaridad AS "ESCOLARIDAD",
    
    COUNT(*) AS "TOTAL EMPLEADOS",
    TO_CHAR(round(MAX(salario)),'fml999G999G999')  AS "SALARIO M�XIMO",
    TO_CHAR(round(MIN(salario)),'fml999G999G999')  AS "SALARIO M�NIMO",
    TO_CHAR(round(SUM(salario)),'fml999G999G999') AS "TOTAL SALARIOS",
    TO_CHAR(round(AVG(salario)),'fml999G999G999') AS "SALARIO PROMEDIO"
FROM
    empleado
GROUP BY
    id_escolaridad
ORDER BY
    COUNT(*) DESC;