SELECT
    c.carreraid"IDENTIFICACION DE LA CARRERA",
    COUNT(a.alumnoid) "TOTAL ALUMNOS MATRICULADOS" ,
    'Le corresponden '||to_char(COUNT(a.alumnoid) * 30200,'fml999g999g999')||' del presupuesto total asignado para la publicidad'"MONTO POR PUBLICIDAD"
FROM
    carrera   c
    INNER JOIN alumno a ON c.carreraid = a.carreraid
GROUP BY
    c.carreraid
order by 2 desc, 1;


SELECT
    carreraid "IDENTIFICACION DE LA CARRERA",
    COUNT(carreraid) "TOTAL ALUMNOS MATRICULADOS",
    'Le corresponden '||to_char(COUNT(carreraid) * 30200,'fml99g999g999')||' del presupuesto total asignado para la publicidad' "MONTO POR PUBLICIDAD"
FROM
    alumno
GROUP BY
    carreraid
ORDER BY
    2 DESC,
    1