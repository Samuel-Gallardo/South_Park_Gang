SELECT
    to_char(e.run_emp,'99g999g999') "RUN EMPLEADO",
    add_months(p.fecha_ini_prestamo, - 12),
    count(*)
FROM
prestamo p
inner join empleado e on p.run_emp = e.run_emp
group by 
